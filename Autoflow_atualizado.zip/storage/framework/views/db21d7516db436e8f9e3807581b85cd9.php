<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Financeiro','title' => 'Financeiro · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Financeiro','title' => 'Financeiro · AutoFlow']); ?>
    <div class="space-y-5">
        <?php ($appSettings = \App\Models\AppSetting::allSettings()); ?>
        <?php if(! empty($appSettings['module_cash_register']) || ! empty($appSettings['module_credit_receivables'])): ?>
            <div class="flex flex-wrap justify-end gap-2">
                <?php if(! empty($appSettings['module_cash_register'])): ?>
                    <a href="<?php echo e(route('finance.cash-registers.index')); ?>" class="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold">Caixa</a>
                <?php endif; ?>
                <?php if(! empty($appSettings['module_credit_receivables'])): ?>
                    <a href="<?php echo e(route('finance.credit-receivables.index')); ?>" class="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold">Fiado / contas a receber</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <section class="rounded-lg border border-zinc-200 bg-white p-5">
            <form method="GET" action="<?php echo e(route('finance.index')); ?>" class="grid gap-4 md:grid-cols-[1fr_1fr_auto_auto] md:items-end">
                <label class="block">
                    <span class="text-sm font-medium">Inicio</span>
                    <input name="start" type="date" value="<?php echo e($start); ?>" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
                </label>
                <label class="block">
                    <span class="text-sm font-medium">Fim</span>
                    <input name="end" type="date" value="<?php echo e($end); ?>" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
                </label>
                <button class="rounded-md bg-cyan-700 px-4 py-2.5 text-sm font-semibold text-white">Filtrar</button>
                <a href="<?php echo e(route('finance.export', ['start' => $start, 'end' => $end])); ?>" class="rounded-md border border-zinc-300 px-4 py-2.5 text-center text-sm font-semibold">Exportar CSV</a>
            </form>
        </section>

        <section class="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
            <div class="rounded-lg border border-zinc-200 bg-white p-5">
                <p class="text-sm text-zinc-500">Total do periodo</p>
                <p class="mt-2 text-2xl font-semibold">R$ <?php echo e(number_format((float) $total, 2, ',', '.')); ?></p>
            </div>
            <div class="rounded-lg border border-zinc-200 bg-white p-5">
                <p class="text-sm text-zinc-500">Pagamentos</p>
                <p class="mt-2 text-2xl font-semibold"><?php echo e($count); ?></p>
            </div>
            <div class="rounded-lg border border-zinc-200 bg-white p-5">
                <p class="text-sm text-zinc-500">Ticket medio</p>
                <p class="mt-2 text-2xl font-semibold">R$ <?php echo e(number_format((float) $ticketAverage, 2, ',', '.')); ?></p>
            </div>
            <div class="rounded-lg border border-zinc-200 bg-white p-5">
                <p class="text-sm text-zinc-500">Ordens pendentes</p>
                <p class="mt-2 text-2xl font-semibold"><?php echo e($pendingCount); ?></p>
            </div>
            <?php if(! empty($appSettings['module_credit_receivables'])): ?>
                <div class="rounded-lg border border-zinc-200 bg-white p-5">
                    <p class="text-sm text-zinc-500">Fiado / pendente</p>
                    <p class="mt-2 text-2xl font-semibold"><?php echo e($creditPendingCount); ?></p>
                </div>
            <?php endif; ?>
        </section>

        <section class="grid gap-5 xl:grid-cols-[360px_1fr]">
            <div class="rounded-lg border border-zinc-200 bg-white">
                <div class="border-b border-zinc-200 px-5 py-4">
                    <h2 class="font-semibold">Por metodo</h2>
                </div>
                <div class="divide-y divide-zinc-100">
                    <?php $__empty_1 = true; $__currentLoopData = $totalsByMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $methodTotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between gap-4 px-5 py-4">
                            <div>
                                <p class="font-medium"><?php echo e($methods[$methodTotal->method] ?? $methodTotal->method); ?></p>
                                <p class="text-sm text-zinc-500"><?php echo e($methodTotal->count); ?> registro(s)</p>
                            </div>
                            <p class="font-semibold">R$ <?php echo e(number_format((float) $methodTotal->total, 2, ',', '.')); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="px-5 py-4 text-sm text-zinc-500">Nenhum pagamento no periodo.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="overflow-hidden rounded-lg border border-zinc-200 bg-white">
                <div class="border-b border-zinc-200 px-5 py-4">
                    <h2 class="font-semibold">Pagamentos recebidos</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full min-w-[820px] text-left text-sm">
                        <thead class="bg-zinc-50 text-xs uppercase text-zinc-500">
                            <tr>
                                <th class="px-5 py-3">Data</th>
                                <th class="px-5 py-3">Ordem</th>
                                <th class="px-5 py-3">Cliente</th>
                                <th class="px-5 py-3">Placa</th>
                                <th class="px-5 py-3">Metodo</th>
                                <th class="px-5 py-3 text-right">Valor</th>
                                <th class="px-5 py-3">Registrado por</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-zinc-100">
                            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-5 py-4 text-zinc-600"><?php echo e($payment->paid_at?->format('d/m/Y H:i') ?? '-'); ?></td>
                                    <td class="px-5 py-4 font-medium">
                                        <a href="<?php echo e(route('wash-orders.show', $payment->washOrder)); ?>" class="text-cyan-700 hover:text-cyan-900"><?php echo e($payment->washOrder->code); ?></a>
                                    </td>
                                    <td class="px-5 py-4"><?php echo e($payment->washOrder->customer->name); ?></td>
                                    <td class="px-5 py-4"><?php echo e($payment->washOrder->vehicle->plate); ?></td>
                                    <td class="px-5 py-4"><?php echo e($payment->methodLabel()); ?></td>
                                    <td class="px-5 py-4 text-right font-semibold">R$ <?php echo e(number_format((float) $payment->amount, 2, ',', '.')); ?></td>
                                    <td class="px-5 py-4 text-zinc-600"><?php echo e($payment->user?->name ?? 'Sistema'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="px-5 py-8 text-center text-zinc-500">Nenhum pagamento encontrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="border-t border-zinc-200 px-5 py-4">
                    <?php echo e($payments->links()); ?>

                </div>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /Users/adrianofreitas/www/general-projects/lavaRapidoABS/resources/views/app/finance/index.blade.php ENDPATH**/ ?>