<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Assinatura pendente','title' => 'Assinatura pendente · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Assinatura pendente','title' => 'Assinatura pendente · AutoFlow']); ?>
    <section class="mx-auto max-w-3xl rounded-2xl border border-amber-200 bg-amber-50 p-6 shadow-sm">
        <p class="text-xs font-black uppercase tracking-[0.22em] text-amber-700">Acesso operacional bloqueado</p>
        <h2 class="mt-3 text-2xl font-black text-slate-950">O trial desta unidade expirou.</h2>
        <p class="mt-3 text-sm leading-6 text-amber-950">
            Para proteger o ciclo comercial do AutoFlow, a operação fica bloqueada quando o trial termina e ainda não existe assinatura ativa.
        </p>

        <?php if($currentLocation): ?>
            <div class="mt-5 rounded-2xl border border-amber-200 bg-white p-5 text-sm text-slate-700">
                <p><strong>Unidade:</strong> <?php echo e($currentLocation->name); ?></p>
                <p class="mt-1"><strong>Status:</strong> <?php echo e($currentLocation->accountStatusLabel()); ?></p>
                <?php if($currentLocation->trial_ends_at): ?>
                    <p class="mt-1"><strong>Trial terminou em:</strong> <?php echo e($currentLocation->trial_ends_at->format('d/m/Y')); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <p class="mt-5 text-sm text-slate-600">
            Fale com o dono do produto para ativar a assinatura da unidade e liberar novamente o painel, lavagens, kanban, clientes, equipe e financeiro.
        </p>

        <?php if(auth()->user()->isOwner()): ?>
            <div class="mt-5">
                <a href="<?php echo e(route('subscriptions.show')); ?>" class="inline-flex rounded-xl bg-blue-700 px-5 py-3 text-sm font-black text-white hover:bg-blue-800">Escolher plano</a>
            </div>
        <?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/subscription-blocked.blade.php ENDPATH**/ ?>