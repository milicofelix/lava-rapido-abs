<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Equipe','title' => 'Equipe · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Equipe','title' => 'Equipe · AutoFlow']); ?>
    <?php echo $__env->make('app.components.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
        <form method="GET" class="flex w-full flex-wrap gap-2 sm:w-auto">
            <input name="search" value="<?php echo e($search); ?>" placeholder="Buscar por nome, e-mail, telefone ou perfil" class="w-full rounded-md border border-zinc-300 px-3 py-2 sm:w-80">
            <button class="rounded-md border border-zinc-300 px-4 py-2 text-sm font-semibold">Filtrar</button>
        </form>
        <a href="<?php echo e(route('employees.create')); ?>" class="rounded-md bg-cyan-700 px-4 py-2 text-sm font-semibold text-white">Novo usuario</a>
    </div>

    <div class="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        <table class="min-w-full divide-y divide-zinc-200">
            <thead class="bg-zinc-100 text-left text-sm text-zinc-600">
                <tr>
                    <th class="px-4 py-3">Nome</th>
                    <th class="px-4 py-3">Perfil</th>
                    <th class="px-4 py-3">E-mail</th>
                    <th class="px-4 py-3">Telefone</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3">Ultimo acesso</th>
                    <th class="px-4 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-zinc-100 text-sm">
                <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-3 font-semibold"><?php echo e($employee->name); ?></td>
                        <td class="px-4 py-3"><?php echo e($roles[$employee->role] ?? $employee->role); ?></td>
                        <td class="px-4 py-3"><?php echo e($employee->email); ?></td>
                        <td class="px-4 py-3"><?php echo e($employee->phone ?: '-'); ?></td>
                        <td class="px-4 py-3">
                            <span class="rounded-full px-2.5 py-1 text-xs font-bold <?php echo e($employee->is_active ? 'bg-emerald-50 text-emerald-700' : 'bg-zinc-100 text-zinc-600'); ?>">
                                <?php echo e($employee->is_active ? 'Ativo' : 'Inativo'); ?>

                            </span>
                        </td>
                        <td class="px-4 py-3"><?php echo e($employee->last_login_at?->format('d/m/Y H:i') ?? 'Nunca'); ?></td>
                        <td class="px-4 py-3 text-right">
                            <div class="flex justify-end gap-3">
                                <a href="<?php echo e(route('employees.edit', $employee)); ?>" class="font-semibold text-cyan-700">Editar</a>
                                <?php if($employee->is_active && ! $employee->is(auth()->user())): ?>
                                    <form method="POST" action="<?php echo e(route('employees.destroy', $employee)); ?>" onsubmit="return confirm('Desativar este usuario da equipe?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="font-semibold text-red-700">Desativar</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="px-4 py-8 text-center text-zinc-500">Nenhum usuario da equipe encontrado.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4"><?php echo e($employees->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/employees/index.blade.php ENDPATH**/ ?>