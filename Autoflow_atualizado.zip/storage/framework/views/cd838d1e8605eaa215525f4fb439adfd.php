<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Lavagens','title' => 'Lavagens · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Lavagens','title' => 'Lavagens · AutoFlow']); ?>
    <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
        <form method="GET" class="flex w-full flex-wrap gap-2 sm:w-auto">
            <input name="search" value="<?php echo e($search); ?>" placeholder="Buscar por codigo, cliente ou placa" class="w-full rounded-md border border-zinc-300 px-3 py-2 sm:w-80">
            <select name="status" class="rounded-md border border-zinc-300 px-3 py-2">
                <option value="">Todos os status</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if($status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="rounded-md border border-zinc-300 px-4 py-2 text-sm font-semibold">Filtrar</button>
        </form>
        <div class="flex gap-2">
            <a href="<?php echo e(route('kanban')); ?>" class="rounded-md border border-zinc-300 px-4 py-2 text-sm font-semibold">Kanban</a>
            <a href="<?php echo e(route('wash-orders.create')); ?>" class="rounded-md bg-cyan-700 px-4 py-2 text-sm font-semibold text-white">Nova lavagem</a>
        </div>
    </div>

    <div class="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        <table class="min-w-full divide-y divide-zinc-200">
            <thead class="bg-zinc-100 text-left text-sm text-zinc-600">
                <tr>
                    <th class="px-4 py-3">Codigo</th>
                    <th class="px-4 py-3">Cliente</th>
                    <th class="px-4 py-3">Veiculo</th>
                    <th class="px-4 py-3">Equipe</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3">Previsao</th>
                    <th class="px-4 py-3">Total</th>
                    <th class="px-4 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-zinc-100 text-sm">
                <?php $__empty_1 = true; $__currentLoopData = $washOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $washOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-3 font-semibold"><?php echo e($washOrder->code); ?></td>
                        <td class="px-4 py-3"><?php echo e($washOrder->customer->name); ?></td>
                        <td class="px-4 py-3"><?php echo e($washOrder->vehicle->plate); ?><br><span class="text-zinc-500"><?php echo e($washOrder->vehicle->brand); ?> <?php echo e($washOrder->vehicle->model); ?></span></td>
                        <td class="px-4 py-3 text-zinc-600"><?php echo e($washOrder->teamMembers->isNotEmpty() ? $washOrder->teamMembers->pluck('name')->join(', ') : '-'); ?></td>
                        <td class="px-4 py-3"><?php echo $__env->make('app.wash-orders._status-badge', ['status' => $washOrder->status, 'label' => $washOrder->statusLabel()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        <td class="px-4 py-3"><?php echo e($washOrder->estimated_completion_at?->format('H:i') ?? '-'); ?></td>
                        <td class="px-4 py-3">R$ <?php echo e(number_format((float) $washOrder->total_amount, 2, ',', '.')); ?></td>
                        <td class="px-4 py-3 text-right"><a href="<?php echo e(route('wash-orders.show', $washOrder)); ?>" class="font-semibold text-cyan-700">Abrir</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="8" class="px-4 py-8 text-center text-zinc-500">Nenhuma lavagem encontrada.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4"><?php echo e($washOrders->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/wash-orders/index.blade.php ENDPATH**/ ?>