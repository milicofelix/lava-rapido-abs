<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Nova lavagem','title' => 'Nova lavagem · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Nova lavagem','title' => 'Nova lavagem · AutoFlow']); ?>
    <form method="POST" action="<?php echo e(route('wash-orders.store')); ?>" class="grid gap-5 xl:grid-cols-[1fr_360px]">
        <?php echo csrf_field(); ?>

        <div class="space-y-5">
            <section class="rounded-lg border border-zinc-200 bg-white p-5">
                <?php echo $__env->make('app.components.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="grid gap-4 md:grid-cols-2">
                    <label class="block">
                        <span class="text-sm font-medium">Cliente</span>
                        <select name="customer_id" required data-customer-select class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>" <?php if(old('customer_id') == $customer->id): echo 'selected'; endif; ?>><?php echo e($customer->name); ?> · <?php echo e($customer->phone); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>

                    <label class="block">
                        <span class="text-sm font-medium">Veiculo</span>
                        <select name="vehicle_id" required data-vehicle-select data-old-vehicle="<?php echo e(old('vehicle_id')); ?>" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
                            <option value="">Selecione um cliente primeiro</option>
                        </select>
                        <p data-vehicle-help class="mt-1 text-xs text-zinc-500">Ao escolher o cliente, os veiculos vinculados aparecem aqui.</p>
                        <?php $__errorArgs = ['vehicle_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>

                    <div class="md:col-span-2">
                        <span class="text-sm font-medium">Equipe da lavagem</span>
                        <div class="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="flex items-center gap-3 rounded-md border border-zinc-200 px-3 py-2">
                                    <input name="assigned_user_ids[]" type="checkbox" value="<?php echo e($user->id); ?>" <?php if(in_array($user->id, old('assigned_user_ids', []))): echo 'checked'; endif; ?> class="rounded border-zinc-300">
                                    <span>
                                        <span class="block text-sm font-medium"><?php echo e($user->name); ?></span>
                                        <span class="block text-xs text-zinc-500"><?php echo e($user->roleLabel()); ?></span>
                                    </span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <p class="mt-1 text-xs text-zinc-500">Selecione todos que participam. O primeiro selecionado sera o responsavel principal.</p>
                        <?php $__errorArgs = ['assigned_user_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['assigned_user_ids.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <label class="mt-4 block">
                    <span class="text-sm font-medium">Observacoes</span>
                    <textarea name="notes" rows="4" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2"><?php echo e(old('notes')); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </section>

            <section class="rounded-lg border border-zinc-200 bg-white">
                <div class="border-b border-zinc-200 px-5 py-4">
                    <h2 class="font-semibold">Servicos</h2>
                </div>
                <div class="grid gap-3 p-5 md:grid-cols-2">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex min-h-28 items-start gap-3 rounded-lg border border-zinc-200 p-4">
                            <input name="service_ids[]" type="checkbox" value="<?php echo e($service->id); ?>" data-price="<?php echo e($service->base_price); ?>" data-minutes="<?php echo e($service->estimated_minutes); ?>" <?php if(in_array($service->id, old('service_ids', []))): echo 'checked'; endif; ?> class="mt-1 rounded border-zinc-300">
                            <span>
                                <span class="block font-medium"><?php echo e($service->name); ?></span>
                                <span class="mt-1 block text-sm text-zinc-500"><?php echo e($service->category); ?> · <?php echo e($service->estimated_minutes); ?> min</span>
                                <span class="mt-2 block text-sm font-semibold">R$ <?php echo e(number_format((float) $service->base_price, 2, ',', '.')); ?></span>
                            </span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php $__errorArgs = ['service_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="px-5 pb-4 text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </section>
        </div>

        <aside class="h-fit rounded-lg border border-zinc-200 bg-white p-5">
            <h2 class="font-semibold">Resumo</h2>
            <dl class="mt-4 space-y-3 text-sm">
                <div class="flex justify-between gap-4">
                    <dt class="text-zinc-500">Total</dt>
                    <dd class="font-semibold" id="wash-total">R$ 0,00</dd>
                </div>
                <div class="flex justify-between gap-4">
                    <dt class="text-zinc-500">Tempo estimado</dt>
                    <dd class="font-semibold" id="wash-minutes">0 min</dd>
                </div>
            </dl>
            <button class="mt-5 w-full rounded-md bg-cyan-700 px-4 py-2.5 text-sm font-semibold text-white">Abrir lavagem</button>
            <a href="<?php echo e(route('wash-orders.index')); ?>" class="mt-3 block rounded-md border border-zinc-300 px-4 py-2.5 text-center text-sm font-semibold">Cancelar</a>
        </aside>
    </form>

    <script type="application/json" data-customer-vehicles>
        <?php echo json_encode($customerVehicles, 15, 512) ?>
    </script>
    <script>
        const customerSelect = document.querySelector('[data-customer-select]');
        const vehicleSelect = document.querySelector('[data-vehicle-select]');
        const vehicleHelp = document.querySelector('[data-vehicle-help]');
        const customerVehicles = JSON.parse(document.querySelector('[data-customer-vehicles]').textContent);

        const setVehicleOptions = () => {
            const customerId = customerSelect.value;
            const selectedVehicle = vehicleSelect.dataset.oldVehicle || vehicleSelect.value;
            const vehicles = customerVehicles[customerId] || [];

            vehicleSelect.innerHTML = '';

            if (!customerId) {
                vehicleSelect.append(new Option('Selecione um cliente primeiro', ''));
                vehicleHelp.textContent = 'Ao escolher o cliente, os veiculos vinculados aparecem aqui.';
                vehicleSelect.dataset.oldVehicle = '';
                return;
            }

            if (vehicles.length === 0) {
                vehicleSelect.append(new Option('Cliente sem veiculo cadastrado', ''));
                vehicleHelp.textContent = 'Cadastre um veiculo para este cliente antes de abrir a lavagem.';
                vehicleSelect.dataset.oldVehicle = '';
                return;
            }

            if (vehicles.length > 1) {
                vehicleSelect.append(new Option('Selecione o veiculo', ''));
            }

            vehicles.forEach((vehicle) => {
                vehicleSelect.append(new Option(vehicle.label, vehicle.id));
            });

            if (vehicles.length === 1) {
                vehicleSelect.value = vehicles[0].id;
                vehicleHelp.textContent = 'Veiculo unico do cliente selecionado automaticamente.';
            } else if (vehicles.some((vehicle) => String(vehicle.id) === String(selectedVehicle))) {
                vehicleSelect.value = selectedVehicle;
                vehicleHelp.textContent = 'Escolha um dos veiculos vinculados a este cliente.';
            } else {
                vehicleSelect.value = '';
                vehicleHelp.textContent = 'Escolha um dos veiculos vinculados a este cliente.';
            }

            vehicleSelect.dataset.oldVehicle = '';
        };

        customerSelect.addEventListener('change', setVehicleOptions);
        setVehicleOptions();

        const formatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
        const updateSummary = () => {
            const checked = [...document.querySelectorAll('input[name="service_ids[]"]:checked')];
            const total = checked.reduce((sum, input) => sum + Number(input.dataset.price || 0), 0);
            const minutes = checked.reduce((sum, input) => sum + Number(input.dataset.minutes || 0), 0);
            document.getElementById('wash-total').textContent = formatter.format(total);
            document.getElementById('wash-minutes').textContent = `${minutes} min`;
        };

        document.querySelectorAll('input[name="service_ids[]"]').forEach((input) => input.addEventListener('change', updateSummary));
        updateSummary();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/wash-orders/create.blade.php ENDPATH**/ ?>