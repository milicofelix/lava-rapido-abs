<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Detalhes da solicitação','title' => 'Solicitação · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Detalhes da solicitação','title' => 'Solicitação · AutoFlow']); ?>
    <?php
        $badgeClass = match ($locationRequest->status) {
            \App\Models\WashLocationRequest::STATUS_APPROVED => 'bg-emerald-100 text-emerald-700',
            \App\Models\WashLocationRequest::STATUS_REJECTED => 'bg-rose-100 text-rose-700',
            default => 'bg-amber-100 text-amber-800',
        };
    ?>

    <div class="space-y-5">
        <?php if(session('success')): ?>
            <div class="rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm font-bold text-emerald-800">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="rounded-2xl border border-rose-200 bg-rose-50 px-5 py-4 text-sm font-bold text-rose-800">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="flex flex-wrap items-center justify-between gap-3">
            <a href="<?php echo e(route('super-admin.location-requests.index')); ?>" class="rounded-xl border border-slate-300 px-4 py-2 text-sm font-bold text-slate-700">← Voltar para solicitações</a>
            <span class="rounded-full px-3 py-1 text-xs font-black <?php echo e($badgeClass); ?>"><?php echo e($locationRequest->statusLabel()); ?></span>
        </div>

        <section class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-5">
                <div>
                    <p class="text-xs font-black uppercase tracking-[0.22em] text-blue-600">Lava-rápido solicitado</p>
                    <h2 class="mt-2 text-3xl font-black text-slate-950"><?php echo e($locationRequest->business_name); ?></h2>
                    <p class="mt-2 text-sm text-slate-500">Solicitado em <?php echo e($locationRequest->created_at?->format('d/m/Y H:i')); ?></p>
                </div>

                <?php if($locationRequest->isPending()): ?>
                    <div class="grid gap-3 sm:grid-cols-2">
                        <form method="POST" action="<?php echo e(route('super-admin.location-requests.approve', $locationRequest)); ?>" class="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <label class="text-xs font-black uppercase tracking-[0.18em] text-emerald-700">Aprovar</label>
                            <textarea name="decision_notes" rows="3" class="mt-3 w-full rounded-xl border border-emerald-200 px-3 py-2 text-sm" placeholder="Observação opcional"></textarea>
                            <button class="mt-3 w-full rounded-xl bg-emerald-600 px-4 py-2 text-sm font-black text-white">Aprovar e iniciar trial</button>
                        </form>

                        <form method="POST" action="<?php echo e(route('super-admin.location-requests.reject', $locationRequest)); ?>" class="rounded-2xl border border-rose-200 bg-rose-50 p-4">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <label class="text-xs font-black uppercase tracking-[0.18em] text-rose-700">Rejeitar</label>
                            <textarea name="decision_notes" rows="3" required class="mt-3 w-full rounded-xl border border-rose-200 px-3 py-2 text-sm" placeholder="Motivo obrigatório"></textarea>
                            <button class="mt-3 w-full rounded-xl bg-rose-600 px-4 py-2 text-sm font-black text-white">Rejeitar solicitação</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="rounded-2xl bg-slate-50 p-4 text-sm text-slate-600">
                        <p class="font-bold text-slate-950">Solicitação analisada</p>
                        <p class="mt-1">Decisão em <?php echo e($locationRequest->decided_at?->format('d/m/Y H:i')); ?>.</p>
                        <?php if($locationRequest->decidedBy): ?>
                            <p class="mt-1">Responsável: <strong><?php echo e($locationRequest->decidedBy->name); ?></strong></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php $__errorArgs = ['decision_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-bold text-rose-700"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if($locationRequest->washLocation): ?>
                <div class="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-5">
                    <p class="text-xs font-black uppercase tracking-[0.18em] text-emerald-700">Unidade criada</p>
                    <div class="mt-3 flex flex-wrap items-center justify-between gap-3">
                        <div>
                            <p class="text-lg font-black text-slate-950"><?php echo e($locationRequest->washLocation->name); ?></p>
                            <p class="text-sm text-slate-600">Status: <?php echo e($locationRequest->washLocation->accountStatusLabel()); ?></p>
                            <p class="text-sm text-slate-600">Trial até <?php echo e($locationRequest->washLocation->trial_ends_at?->format('d/m/Y')); ?></p>
                            <?php if($locationRequest->washLocation->subscription_ends_at): ?>
                                <p class="text-sm text-slate-600">Assinatura até <?php echo e($locationRequest->washLocation->subscription_ends_at->format('d/m/Y')); ?></p>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('public.locations.show', $locationRequest->washLocation)); ?>" target="_blank" class="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-black text-white">Ver página pública</a>
                    </div>
                </div>
            <?php endif; ?>

            <div class="mt-6 grid gap-5 lg:grid-cols-2">
                <div class="rounded-2xl border border-slate-200 p-5">
                    <h3 class="font-black text-slate-950">Responsável</h3>
                    <dl class="mt-4 space-y-3 text-sm">
                        <div><dt class="text-slate-500">Nome</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->responsible_name); ?></dd></div>
                        <div><dt class="text-slate-500">E-mail</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->email); ?></dd></div>
                        <div><dt class="text-slate-500">WhatsApp</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->phone); ?></dd></div>
                    </dl>
                </div>

                <div class="rounded-2xl border border-slate-200 p-5">
                    <h3 class="font-black text-slate-950">Unidade</h3>
                    <dl class="mt-4 space-y-3 text-sm">
                        <div><dt class="text-slate-500">Endereço</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->address); ?></dd></div>
                        <div><dt class="text-slate-500">Bairro</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->district ?: 'Não informado'); ?></dd></div>
                        <div><dt class="text-slate-500">Cidade/UF</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->city); ?>/<?php echo e($locationRequest->state); ?></dd></div>
                        <div><dt class="text-slate-500">CEP</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->zip_code ?: 'Não informado'); ?></dd></div>
                        <div><dt class="text-slate-500">Funcionários</dt><dd class="font-bold text-slate-950"><?php echo e($locationRequest->employees_count ?: 'Não informado'); ?></dd></div>
                    </dl>
                </div>
            </div>

            <div class="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-5">
                <h3 class="font-black text-slate-950">Mensagem</h3>
                <p class="mt-3 whitespace-pre-line text-sm leading-6 text-slate-600"><?php echo e($locationRequest->notes ?: 'Nenhuma observação enviada.'); ?></p>
            </div>

            <?php if($locationRequest->decision_notes): ?>
                <div class="mt-5 rounded-2xl border border-slate-200 bg-white p-5">
                    <h3 class="font-black text-slate-950">Observação da decisão</h3>
                    <p class="mt-3 whitespace-pre-line text-sm leading-6 text-slate-600"><?php echo e($locationRequest->decision_notes); ?></p>
                </div>
            <?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /Users/adrianofreitas/www/general-projects/lavaRapidoABS/resources/views/app/super-admin/location-requests/show.blade.php ENDPATH**/ ?>