<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Solicitações de lava-rápidos','title' => 'Solicitações · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Solicitações de lava-rápidos','title' => 'Solicitações · AutoFlow']); ?>
    <div class="space-y-5">
        <div class="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-950">
            <p class="font-bold">Área do dono do produto</p>
            <p class="mt-1">Ao aprovar uma solicitação, a unidade nasce em trial e passa a seguir as regras de assinatura do SaaS.</p>
        </div>

        <section class="grid gap-4 md:grid-cols-4">
            <div class="rounded-xl border border-slate-200 bg-white p-5">
                <p class="text-sm text-slate-500">Pendentes</p>
                <p class="mt-2 text-2xl font-black text-amber-700"><?php echo e($summary['pending']); ?></p>
            </div>
            <div class="rounded-xl border border-slate-200 bg-white p-5">
                <p class="text-sm text-slate-500">Aprovadas</p>
                <p class="mt-2 text-2xl font-black text-emerald-700"><?php echo e($summary['approved']); ?></p>
            </div>
            <div class="rounded-xl border border-slate-200 bg-white p-5">
                <p class="text-sm text-slate-500">Rejeitadas</p>
                <p class="mt-2 text-2xl font-black text-rose-700"><?php echo e($summary['rejected']); ?></p>
            </div>
            <div class="rounded-xl border border-slate-200 bg-white p-5">
                <p class="text-sm text-slate-500">Total</p>
                <p class="mt-2 text-2xl font-black text-slate-950"><?php echo e($summary['total']); ?></p>
            </div>
        </section>

        <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <form method="GET" class="grid gap-3 lg:grid-cols-[1fr_240px_auto_auto]">
                <input name="search" value="<?php echo e($search); ?>" placeholder="Buscar por responsável, e-mail, telefone, lava-rápido ou cidade" class="rounded-xl border border-slate-300 px-4 py-2 text-sm">
                <select name="status" class="rounded-xl border border-slate-300 px-4 py-2 text-sm">
                    <option value="">Todos os status</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if($status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="rounded-xl bg-slate-950 px-5 py-2 text-sm font-bold text-white">Filtrar</button>
                <a href="<?php echo e(route('super-admin.location-requests.index')); ?>" class="rounded-xl border border-slate-300 px-5 py-2 text-center text-sm font-bold text-slate-700">Limpar</a>
            </form>
        </section>

        <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-black text-slate-950">Solicitações recebidas</h2>
                <p class="mt-1 text-sm text-slate-500">Controle manual antes de publicar qualquer unidade no mapa.</p>
            </div>

            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requestItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $badgeClass = match ($requestItem->status) {
                            \App\Models\WashLocationRequest::STATUS_APPROVED => 'bg-emerald-100 text-emerald-700',
                            \App\Models\WashLocationRequest::STATUS_REJECTED => 'bg-rose-100 text-rose-700',
                            default => 'bg-amber-100 text-amber-800',
                        };
                    ?>
                    <article class="grid gap-4 px-5 py-5 lg:grid-cols-[1fr_220px]">
                        <div>
                            <div class="flex flex-wrap items-center gap-2">
                                <a href="<?php echo e(route('super-admin.location-requests.show', $requestItem)); ?>" class="text-lg font-black text-blue-700 hover:text-blue-900"><?php echo e($requestItem->business_name); ?></a>
                                <span class="rounded-full px-3 py-1 text-xs font-black <?php echo e($badgeClass); ?>"><?php echo e($requestItem->statusLabel()); ?></span>
                            </div>
                            <p class="mt-2 text-sm text-slate-600">Responsável: <strong><?php echo e($requestItem->responsible_name); ?></strong></p>
                            <p class="mt-1 text-sm text-slate-500"><?php echo e($requestItem->city); ?>/<?php echo e($requestItem->state); ?> · <?php echo e($requestItem->phone); ?> · <?php echo e($requestItem->email); ?></p>
                            <p class="mt-1 text-xs text-slate-400">Solicitado em <?php echo e($requestItem->created_at?->format('d/m/Y H:i')); ?></p>
                            <?php if($requestItem->washLocation): ?>
                                <p class="mt-2 text-xs font-bold text-emerald-700">Unidade: <?php echo e($requestItem->washLocation->accountStatusLabel()); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="flex items-center justify-start lg:justify-end">
                            <a href="<?php echo e(route('super-admin.location-requests.show', $requestItem)); ?>" class="rounded-xl border border-slate-300 px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50">Ver detalhes</a>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-10 text-center text-sm text-slate-500">Nenhuma solicitação encontrada.</p>
                <?php endif; ?>
            </div>

            <div class="border-t border-slate-200 px-5 py-4">
                <?php echo e($requests->links()); ?>

            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /Users/adrianofreitas/www/general-projects/lavaRapidoABS/resources/views/app/super-admin/location-requests/index.blade.php ENDPATH**/ ?>