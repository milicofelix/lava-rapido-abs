<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'AutoFlow'); ?></title>
    <script>
        (() => {
            const preferredTheme = <?php echo json_encode(\App\Models\AppSetting::theme(), 15, 512) ?>;
            const resolvedTheme = preferredTheme === 'system'
                ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
                : preferredTheme;

            document.documentElement.dataset.theme = preferredTheme;
            document.documentElement.dataset.themeEffective = resolvedTheme;
        })();
    </script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<?php ($appSettings = \App\Models\AppSetting::allSettings()); ?>
<?php ($appTheme = \App\Models\AppSetting::theme()); ?>
<?php ($currentLocation = \App\Support\TenantContext::currentLocation()); ?>
<?php ($isSuperAdmin = auth()->user()->isSuperAdmin()); ?>
<?php ($unitDisplayName = $currentLocation?->name ?? ($isSuperAdmin ? 'AutoFlow Admin' : ($appSettings['company_name'] ?? 'AutoFlow'))); ?>
<?php ($unitStatusLabel = $currentLocation?->accountStatusLabel()); ?>
<?php ($trialDaysRemaining = $currentLocation?->trialDaysRemaining()); ?>
<?php ($homeRoute = $isSuperAdmin ? route('super-admin.location-requests.index') : route('dashboard')); ?>
<body class="<?php echo e($appTheme === 'dark' ? 'bg-slate-950' : 'bg-[#061832]'); ?> text-slate-950 antialiased" data-theme="<?php echo e($appTheme); ?>" data-theme-effective="<?php echo e($appTheme === 'system' ? 'light' : $appTheme); ?>">
    <div class="min-h-screen p-2 lg:p-3" data-app-shell>
        <aside data-sidebar class="fixed inset-y-3 left-3 z-30 hidden w-72 flex-col rounded-2xl <?php echo e($appTheme === 'dark' ? 'bg-slate-950' : 'bg-[#061b36]'); ?> px-3 py-3 text-white shadow-2xl shadow-black/30 transition-transform duration-200 lg:flex">
            <a href="<?php echo e($homeRoute); ?>" class="block shrink-0 rounded-2xl bg-white px-6 py-6 shadow-inner shadow-slate-200">
                <img src="<?php echo e(asset('images/autoflow-logo.png')); ?>" alt="AutoFlow" class="mx-auto h-auto w-52">
            </a>

            <nav class="mt-4 min-h-0 flex-1 space-y-1.5 overflow-y-auto pr-1">
                <?php if($isSuperAdmin): ?>
                    <a href="<?php echo e(route('super-admin.location-requests.index')); ?>" class="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition <?php echo e(request()->routeIs('super-admin.location-requests.*') ? 'bg-blue-600 text-white shadow-lg shadow-blue-950/30' : 'text-slate-200 hover:bg-white/10 hover:text-white'); ?>">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-white/10 text-xs font-bold">S</span>
                        Solicitações de cadastros
                    </a>
                    <a href="<?php echo e(route('super-admin.locations.index')); ?>" class="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition <?php echo e(request()->routeIs('super-admin.locations.*') ? 'bg-blue-600 text-white shadow-lg shadow-blue-950/30' : 'text-slate-200 hover:bg-white/10 hover:text-white'); ?>">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-white/10 text-xs font-bold">U</span>
                        Unidades
                    </a>
                    <a href="<?php echo e(route('super-admin.plans.index')); ?>" class="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition <?php echo e(request()->routeIs('super-admin.plans.*') ? 'bg-blue-600 text-white shadow-lg shadow-blue-950/30' : 'text-slate-200 hover:bg-white/10 hover:text-white'); ?>">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-white/10 text-xs font-bold">P</span>
                        Planos
                    </a>
                <?php else: ?>
                    <?php $__currentLoopData = [
                        ['route' => 'dashboard', 'label' => 'Painel Principal', 'icon' => 'P', 'roles' => null],
                        ['route' => 'wash-orders.index', 'label' => 'Lavagens', 'icon' => 'L', 'roles' => null],
                        ['route' => 'kanban', 'label' => 'Kanban de Lavagens', 'icon' => 'K', 'roles' => null],
                        ['route' => 'history.index', 'label' => 'Historico', 'icon' => 'H', 'roles' => null],
                        ['route' => 'customers.index', 'label' => 'Clientes', 'icon' => 'C', 'roles' => ['admin', 'attendant']],
                        ['route' => 'vehicles.index', 'label' => 'Veiculos', 'icon' => 'V', 'roles' => ['admin', 'attendant']],
                        ['route' => 'services.index', 'label' => 'Servicos', 'icon' => 'S', 'roles' => ['owner', 'admin']],
                        ['route' => 'employees.index', 'label' => 'Equipe', 'icon' => 'E', 'roles' => ['owner', 'admin']],
                        ['route' => 'finance.index', 'label' => 'Financeiro', 'icon' => '$', 'roles' => ['owner', 'admin']],
                        ['route' => 'finance.cash-registers.index', 'label' => 'Caixa', 'icon' => 'CX', 'roles' => ['owner', 'admin'], 'module' => 'module_cash_register'],
                        ['route' => 'finance.credit-receivables.index', 'label' => 'Fiado', 'icon' => 'F$', 'roles' => ['owner', 'admin'], 'module' => 'module_credit_receivables'],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['roles'] && ! auth()->user()->hasAnyRole($item['roles'])) continue; ?>
                        <?php if(($item['module'] ?? null) && empty($appSettings[$item['module']])) continue; ?>
                        <a href="<?php echo e(route($item['route'])); ?>" class="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition <?php echo e(request()->routeIs($item['route']) || request()->routeIs(str_replace('.index', '.*', $item['route'])) ? 'bg-blue-600 text-white shadow-lg shadow-blue-950/30' : 'text-slate-200 hover:bg-white/10 hover:text-white'); ?>">
                            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-white/10 text-xs font-bold"><?php echo e($item['icon']); ?></span>
                            <?php echo e($item['label']); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = [
                        ['label' => 'Relatorios', 'icon' => 'R', 'href' => auth()->user()->isTeamManager() ? route('finance.index') : route('dashboard'), 'roles' => ['owner', 'admin']],
                        ['label' => 'Assinatura', 'icon' => 'A', 'href' => route('subscriptions.show'), 'roles' => ['owner']],
                        ['label' => 'Configuracoes', 'icon' => 'G', 'href' => route('settings.edit'), 'roles' => ['owner', 'admin']],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($item['roles'] ?? null) && ! auth()->user()->hasAnyRole($item['roles'])) continue; ?>
                        <a href="<?php echo e($item['href']); ?>" class="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-slate-200 transition hover:bg-white/10 hover:text-white">
                            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-white/10 text-xs font-bold"><?php echo e($item['icon']); ?></span>
                            <?php echo e($item['label']); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </nav>

            <div class="mt-4 shrink-0 rounded-2xl border border-white/10 bg-[#082646] p-3 text-center shadow-inner shadow-white/5">
                <div class="mx-auto flex h-20 w-full items-end justify-center overflow-hidden rounded-xl bg-gradient-to-t from-blue-950 to-blue-700">
                    <img src="<?php echo e(asset('images/autoflow-logo.png')); ?>" alt="AutoFlow" class="mb-2 w-24 opacity-90">
                </div>
                <p class="mt-3 text-sm font-semibold">Organize. Acompanhe.</p>
                <p class="text-sm font-semibold text-cyan-300">Fidelize.</p>
                <p class="mt-2 text-[11px] leading-4 text-slate-300">Mais controle, eficiencia e satisfacao para seus clientes.</p>
            </div>
        </aside>

        <div data-content class="min-h-[calc(100vh-16px)] overflow-hidden rounded-2xl <?php echo e($appTheme === 'dark' ? 'bg-slate-900 text-slate-100' : 'bg-slate-50'); ?> shadow-2xl shadow-black/30 transition-[margin] duration-200 lg:ml-80">
            <header class="sticky top-0 z-20 border-b <?php echo e($appTheme === 'dark' ? 'border-slate-800 bg-slate-950/95' : 'border-slate-200 bg-white/95'); ?> px-4 py-4 backdrop-blur sm:px-6 lg:px-8">
                <div class="flex flex-wrap items-center justify-between gap-4">
                    <div class="flex items-center gap-4">
                        <button type="button" data-sidebar-toggle aria-label="Ocultar menu" title="Ocultar menu" aria-expanded="true" class="hidden h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 shadow-sm transition hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 lg:inline-flex">
                            <svg data-sidebar-icon-open xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <rect x="3" y="4" width="18" height="16" rx="2"></rect>
                                <path d="M9 4v16"></path>
                                <path d="M14 10l-2 2 2 2"></path>
                            </svg>
                            <svg data-sidebar-icon-closed xmlns="http://www.w3.org/2000/svg" class="hidden h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M4 6h16"></path>
                                <path d="M4 12h16"></path>
                                <path d="M4 18h16"></path>
                            </svg>
                        </button>
                        <div>
                            <h1 class="text-xl font-bold <?php echo e($appTheme === 'dark' ? 'text-white' : 'text-slate-950'); ?> sm:text-2xl"><?php echo e($heading ?? 'Painel Principal'); ?></h1>
                            <p class="text-sm text-slate-500"><?php echo e($isSuperAdmin ? 'Gerencie aprovações e cadastros da plataforma.' : 'Aqui esta o resumo do que acontece hoje.'); ?></p>
                        </div>
                    </div>

                    <div class="flex items-center gap-3">
                        <div class="hidden max-w-xs items-center gap-3 rounded-lg border <?php echo e($appTheme === 'dark' ? 'border-slate-700 bg-slate-900' : 'border-slate-200 bg-white'); ?> px-4 py-2 shadow-sm md:flex">
                            <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg <?php echo e($currentLocation ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-700'); ?> text-sm font-black"><?php echo e($currentLocation ? strtoupper(substr($currentLocation->name, 0, 1)) : 'A'); ?></span>
                            <div class="min-w-0">
                                <p class="text-xs text-slate-500"><?php echo e($isSuperAdmin ? 'Administração do produto' : 'Unidade atual'); ?></p>
                                <p class="truncate text-sm font-semibold <?php echo e($appTheme === 'dark' ? 'text-white' : 'text-slate-950'); ?>"><?php echo e($unitDisplayName); ?></p>
                                <?php if($currentLocation): ?>
                                    <p class="truncate text-[11px] font-semibold text-slate-500">
                                        <?php echo e($unitStatusLabel); ?>

                                        <?php if($trialDaysRemaining !== null && $currentLocation->account_status === \App\Models\WashLocation::ACCOUNT_STATUS_TRIAL): ?>
                                            · Trial: <?php echo e($trialDaysRemaining); ?> dia<?php echo e($trialDaysRemaining === 1 ? '' : 's'); ?>

                                        <?php endif; ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="hidden items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-600 shadow-sm md:flex" data-theme-status>
                            <span class="h-2.5 w-2.5 rounded-full bg-cyan-400"></span>
                            <span>Tema <?php echo e($appTheme === 'dark' ? 'dark ativo' : ($appTheme === 'system' ? 'sistema' : 'claro')); ?></span>
                        </div>
                        <div class="flex items-center gap-3 rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-sm">
                            <span class="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 text-sm font-bold text-white"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                            <div class="hidden sm:block">
                                <p class="text-sm font-semibold"><?php echo e(auth()->user()->name); ?></p>
                                <p class="text-xs text-slate-500"><?php echo e(auth()->user()->roleLabel()); ?></p>
                            </div>
                        </div>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="rounded-lg bg-slate-950 px-3 py-2 text-sm font-semibold text-white">Sair</button>
                        </form>
                    </div>
                </div>

                <nav class="mt-4 flex gap-2 overflow-x-auto lg:hidden">
                    <?php if($isSuperAdmin): ?>
                        <a href="<?php echo e(route('super-admin.location-requests.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Solicitações</a>
                        <a href="<?php echo e(route('super-admin.locations.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Unidades</a>
                        <a href="<?php echo e(route('super-admin.plans.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Planos</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Painel</a>
                        <a href="<?php echo e(route('wash-orders.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Lavagens</a>
                        <a href="<?php echo e(route('kanban')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Kanban</a>
                        <a href="<?php echo e(route('history.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Historico</a>
                        <?php if(auth()->user()->isTeamManager()): ?>
                            <a href="<?php echo e(route('finance.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Financeiro</a>
                            <?php if(! empty($appSettings['module_cash_register'])): ?>
                                <a href="<?php echo e(route('finance.cash-registers.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Caixa</a>
                            <?php endif; ?>
                            <?php if(! empty($appSettings['module_credit_receivables'])): ?>
                                <a href="<?php echo e(route('finance.credit-receivables.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Fiado</a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('employees.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Equipe</a>
                            <?php if(auth()->user()->isOwner()): ?>
                                <a href="<?php echo e(route('subscriptions.show')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Assinatura</a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('settings.edit')); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm">Configuracoes</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </nav>
            </header>

            <main class="px-4 py-5 sm:px-6 lg:px-8">
                <?php if(session('status')): ?>
                    <div class="mb-5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <?php if($currentLocation && $currentLocation->subscriptionStatus() === \App\Models\WashLocation::ACCOUNT_STATUS_TRIAL && $trialDaysRemaining !== null && $trialDaysRemaining <= 5): ?>
                    <div class="mb-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
                        <strong>Trial em andamento:</strong>
                        restam <?php echo e($trialDaysRemaining); ?> dia<?php echo e($trialDaysRemaining === 1 ? '' : 's'); ?> para ativar a assinatura da unidade.
                    </div>
                <?php endif; ?>

                <?php echo e($slot); ?>

            </main>
        </div>
    </div>

    <script>
        const preferredTheme = document.body.dataset.theme || 'light';
        const themeMedia = window.matchMedia('(prefers-color-scheme: dark)');
        const applyResolvedTheme = () => {
            const resolvedTheme = preferredTheme === 'system' && themeMedia.matches ? 'dark' : (preferredTheme === 'dark' ? 'dark' : 'light');

            document.documentElement.dataset.theme = preferredTheme;
            document.documentElement.dataset.themeEffective = resolvedTheme;
            document.body.dataset.themeEffective = resolvedTheme;
        };

        applyResolvedTheme();
        themeMedia.addEventListener?.('change', applyResolvedTheme);

        const shell = document.querySelector('[data-app-shell]');
        const sidebar = document.querySelector('[data-sidebar]');
        const content = document.querySelector('[data-content]');
        const sidebarToggle = document.querySelector('[data-sidebar-toggle]');
        const sidebarIconOpen = document.querySelector('[data-sidebar-icon-open]');
        const sidebarIconClosed = document.querySelector('[data-sidebar-icon-closed]');
        const sidebarStorageKey = 'autoflow.sidebar.collapsed';

        const applySidebarState = (collapsed) => {
            sidebar.classList.toggle('-translate-x-[calc(100%+1rem)]', collapsed);
            content.classList.toggle('lg:ml-80', !collapsed);
            content.classList.toggle('lg:ml-0', collapsed);
            sidebarToggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
            sidebarToggle.setAttribute('aria-label', collapsed ? 'Mostrar menu' : 'Ocultar menu');
            sidebarToggle.setAttribute('title', collapsed ? 'Mostrar menu' : 'Ocultar menu');
            sidebarIconOpen.classList.toggle('hidden', collapsed);
            sidebarIconClosed.classList.toggle('hidden', !collapsed);
            shell.dataset.sidebarCollapsed = collapsed ? 'true' : 'false';
        };

        const initialSidebarCollapsed = localStorage.getItem(sidebarStorageKey) === 'true';
        applySidebarState(initialSidebarCollapsed);

        sidebarToggle.addEventListener('click', () => {
            const collapsed = shell.dataset.sidebarCollapsed !== 'true';

            localStorage.setItem(sidebarStorageKey, collapsed ? 'true' : 'false');
            applySidebarState(collapsed);
        });

        document.querySelectorAll('[data-copy-message-button]').forEach((button) => {
            button.addEventListener('click', async () => {
                const textarea = button.closest('section')?.querySelector('[data-copy-message]');

                if (! textarea) {
                    return;
                }

                try {
                    await navigator.clipboard.writeText(textarea.value);
                    button.textContent = 'Mensagem copiada';
                } catch (error) {
                    textarea.select();
                    document.execCommand('copy');
                    button.textContent = 'Mensagem copiada';
                }
            });
        });
    </script>
</body>
</html>
<?php /**PATH /Users/adrianofreitas/www/general-projects/lavaRapidoABS/resources/views/components/app/layout.blade.php ENDPATH**/ ?>