<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Veiculos','title' => 'Veiculos · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Veiculos','title' => 'Veiculos · AutoFlow']); ?>
    <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
        <form method="GET" class="flex w-full gap-2 sm:w-auto">
            <input name="search" value="<?php echo e($search); ?>" placeholder="Buscar por placa, modelo, marca ou cliente" class="w-full rounded-md border border-zinc-300 px-3 py-2 sm:w-96">
            <button class="rounded-md border border-zinc-300 px-4 py-2 text-sm font-semibold">Buscar</button>
        </form>
        <a href="<?php echo e(route('vehicles.create')); ?>" class="rounded-md bg-cyan-700 px-4 py-2 text-sm font-semibold text-white">Novo veiculo</a>
    </div>

    <div class="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        <table class="min-w-full divide-y divide-zinc-200">
            <thead class="bg-zinc-100 text-left text-sm text-zinc-600">
                <tr>
                    <th class="px-4 py-3">Placa</th>
                    <th class="px-4 py-3">Veiculo</th>
                    <th class="px-4 py-3">Cliente</th>
                    <th class="px-4 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-zinc-100 text-sm">
                <?php $__empty_1 = true; $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-3 font-semibold"><?php echo e($vehicle->plate); ?></td>
                        <td class="px-4 py-3"><?php echo e($vehicle->brand); ?> <?php echo e($vehicle->model); ?><br><span class="text-zinc-500"><?php echo e($vehicle->color); ?> · <?php echo e(ucfirst($vehicle->type)); ?></span></td>
                        <td class="px-4 py-3"><?php echo e($vehicle->customer->name); ?></td>
                        <td class="px-4 py-3 text-right"><a href="<?php echo e(route('vehicles.edit', $vehicle)); ?>" class="font-semibold text-cyan-700">Editar</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-4 py-8 text-center text-zinc-500">Nenhum veiculo encontrado.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4"><?php echo e($vehicles->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/vehicles/index.blade.php ENDPATH**/ ?>