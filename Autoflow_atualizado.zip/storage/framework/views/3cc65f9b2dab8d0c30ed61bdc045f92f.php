<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Lavagem '.e($washOrder->code).'','title' => 'Lavagem '.e($washOrder->code).' · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Lavagem '.e($washOrder->code).'','title' => 'Lavagem '.e($washOrder->code).' · AutoFlow']); ?>
    <div class="grid gap-5 xl:grid-cols-[1fr_360px]">
        <div class="space-y-5">
            <section class="rounded-lg border border-zinc-200 bg-white p-5">
                <div class="flex flex-wrap items-start justify-between gap-4">
                    <div>
                        <p class="text-sm text-zinc-500">Cliente</p>
                        <h2 class="text-xl font-semibold"><?php echo e($washOrder->customer->name); ?></h2>
                        <p class="mt-1 text-sm text-zinc-600"><?php echo e($washOrder->customer->phone); ?></p>
                    </div>
                    <?php echo $__env->make('app.wash-orders._status-badge', ['status' => $washOrder->status, 'label' => $washOrder->statusLabel()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <dl class="mt-5 grid gap-4 md:grid-cols-3">
                    <div>
                        <dt class="text-sm text-zinc-500">Veiculo</dt>
                        <dd class="font-medium"><?php echo e($washOrder->vehicle->plate); ?> · <?php echo e($washOrder->vehicle->brand); ?> <?php echo e($washOrder->vehicle->model); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-zinc-500">Entrada</dt>
                        <dd class="font-medium"><?php echo e($washOrder->entered_at->format('d/m/Y H:i')); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-zinc-500">Previsao</dt>
                        <dd class="font-medium"><?php echo e($washOrder->estimated_completion_at?->format('d/m/Y H:i') ?? '-'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-zinc-500">Equipe</dt>
                        <dd class="font-medium">
                            <?php echo e($washOrder->teamMembers->isNotEmpty() ? $washOrder->teamMembers->pluck('name')->join(', ') : 'Sem equipe definida'); ?>

                        </dd>
                    </div>
                    <div>
                        <dt class="text-sm text-zinc-500">Total</dt>
                        <dd class="font-medium">R$ <?php echo e(number_format((float) $washOrder->total_amount, 2, ',', '.')); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-zinc-500">Financeiro</dt>
                        <dd class="font-medium"><?php echo e($washOrder->paymentStatusLabel()); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm text-zinc-500">Conclusao</dt>
                        <dd class="font-medium"><?php echo e($washOrder->completed_at?->format('d/m/Y H:i') ?? '-'); ?></dd>
                    </div>
                </dl>

                <?php if($washOrder->notes): ?>
                    <p class="mt-5 rounded-md bg-zinc-100 px-4 py-3 text-sm text-zinc-700"><?php echo e($washOrder->notes); ?></p>
                <?php endif; ?>
            </section>

            <section class="rounded-lg border border-zinc-200 bg-white">
                <div class="border-b border-zinc-200 px-5 py-4">
                    <h2 class="font-semibold">Servicos selecionados</h2>
                </div>
                <div class="divide-y divide-zinc-100">
                    <?php $__currentLoopData = $washOrder->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between gap-4 px-5 py-4">
                            <div>
                                <p class="font-medium"><?php echo e($service->pivot->service_name); ?></p>
                                <p class="text-sm text-zinc-500"><?php echo e($service->pivot->estimated_minutes); ?> min</p>
                            </div>
                            <p class="font-semibold">R$ <?php echo e(number_format((float) $service->pivot->price, 2, ',', '.')); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>

            <section class="rounded-lg border border-zinc-200 bg-white">
                <div class="border-b border-zinc-200 px-5 py-4">
                    <h2 class="font-semibold">Pagamentos</h2>
                </div>
                <div class="divide-y divide-zinc-100">
                    <?php $__empty_1 = true; $__currentLoopData = $washOrder->payments->sortByDesc('paid_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="px-5 py-4">
                            <div class="flex flex-wrap items-start justify-between gap-3">
                                <div>
                                    <p class="font-medium"><?php echo e($payment->methodLabel()); ?></p>
                                    <p class="text-sm text-zinc-500">
                                        <?php echo e($payment->paid_at?->format('d/m/Y H:i') ?? '-'); ?> · <?php echo e($payment->user?->name ?? 'Sistema'); ?>

                                    </p>
                                </div>
                                <p class="font-semibold">R$ <?php echo e(number_format((float) $payment->amount, 2, ',', '.')); ?></p>
                            </div>
                            <?php if($payment->notes): ?>
                                <p class="mt-2 text-sm text-zinc-700"><?php echo e($payment->notes); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="px-5 py-4 text-sm text-zinc-500">Nenhum pagamento registrado.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="rounded-lg border border-zinc-200 bg-white">
                <div class="border-b border-zinc-200 px-5 py-4">
                    <h2 class="font-semibold">Historico de status</h2>
                </div>
                <div class="divide-y divide-zinc-100">
                    <?php $__currentLoopData = $washOrder->statusHistories->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="px-5 py-4">
                            <div class="flex flex-wrap items-center justify-between gap-3">
                                <p class="font-medium"><?php echo e($statuses[$history->to_status] ?? $history->to_status); ?></p>
                                <p class="text-sm text-zinc-500"><?php echo e($history->created_at->format('d/m/Y H:i')); ?></p>
                            </div>
                            <p class="mt-1 text-sm text-zinc-500"><?php echo e($history->user?->name ?? 'Sistema'); ?></p>
                            <?php if($history->notes): ?>
                                <p class="mt-2 text-sm text-zinc-700"><?php echo e($history->notes); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        </div>

        <aside class="h-fit rounded-lg border border-zinc-200 bg-white p-5">
            <section class="mb-5 rounded-md border border-emerald-200 bg-emerald-50 p-4">
                <h2 class="font-semibold text-emerald-950">Registrar pagamento</h2>
                <form method="POST" action="<?php echo e(route('payments.store', $washOrder)); ?>" class="mt-4 space-y-3">
                    <?php echo csrf_field(); ?>
                    <label class="block">
                        <span class="text-sm font-medium">Metodo</span>
                        <select name="method" class="mt-1 w-full rounded-md border border-emerald-200 bg-white px-3 py-2">
                            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php if(old('method', 'pix') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <label class="block">
                        <span class="text-sm font-medium">Valor</span>
                        <input name="amount" type="number" min="0" step="0.01" value="<?php echo e(old('amount', $washOrder->total_amount)); ?>" class="mt-1 w-full rounded-md border border-emerald-200 bg-white px-3 py-2">
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <label class="block">
                        <span class="text-sm font-medium">Observacao</span>
                        <textarea name="notes" rows="3" class="mt-1 w-full rounded-md border border-emerald-200 bg-white px-3 py-2"><?php echo e(old('notes')); ?></textarea>
                        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <button class="w-full rounded-md bg-emerald-700 px-4 py-2.5 text-sm font-semibold text-white">Registrar pagamento</button>
                </form>
            </section>

            <section class="mb-5 rounded-md border border-cyan-200 bg-cyan-50 p-4">
                <h2 class="font-semibold text-cyan-950">Link do cliente</h2>
                <p class="mt-1 text-xs text-cyan-800">Compartilhe este link para o cliente acompanhar a lavagem em tempo real.</p>
                <a href="<?php echo e($washOrder->trackingUrl()); ?>" target="_blank" class="mt-3 block break-all text-sm font-medium text-cyan-800"><?php echo e($washOrder->trackingUrl()); ?></a>
                <?php if($washOrder->customer->whatsappTrackingUrl($washOrder)): ?>
                    <a href="<?php echo e($washOrder->customer->whatsappTrackingUrl($washOrder)); ?>" target="_blank" rel="noopener" class="mt-3 inline-flex rounded-md bg-emerald-700 px-3 py-2 text-xs font-semibold text-white">Compartilhar via WhatsApp</a>
                <?php endif; ?>

                <div class="mt-5 border-t border-cyan-200 pt-4">
                    <h3 class="font-semibold text-cyan-950">Notificacao manual</h3>
                    <p class="mt-1 text-xs text-cyan-800">Prepare a mensagem e envie manualmente pelo WhatsApp. Nenhuma API paga e usada nesta fase.</p>
                </div>

                <form method="POST" action="<?php echo e(route('wash-orders.notifications.whatsapp-manual.store', $washOrder)); ?>" class="mt-4 space-y-3">
                    <?php echo csrf_field(); ?>
                    <label class="block">
                        <span class="text-sm font-medium">Modelo de mensagem</span>
                        <select name="template_key" class="mt-1 w-full rounded-md border border-cyan-200 bg-white px-3 py-2">
                            <?php $__currentLoopData = $notificationTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php if(old('template_key') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['template_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <label class="block">
                        <span class="text-sm font-medium">Observacao opcional</span>
                        <textarea name="notes" rows="2" class="mt-1 w-full rounded-md border border-cyan-200 bg-white px-3 py-2" placeholder="Ex.: Estamos finalizando a secagem."><?php echo e(old('notes')); ?></textarea>
                        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <button class="w-full rounded-md bg-cyan-700 px-4 py-2.5 text-sm font-semibold text-white">Preparar mensagem</button>
                </form>

                <?php ($lastNotification = $washOrder->customerNotifications->sortByDesc('created_at')->first()); ?>
                <?php if($lastNotification): ?>
                    <div class="mt-4 rounded-md border border-cyan-200 bg-white p-3">
                        <div class="flex items-start justify-between gap-3">
                            <div>
                                <p class="text-sm font-semibold text-slate-950">Ultima mensagem preparada</p>
                                <p class="text-xs text-slate-500"><?php echo e($lastNotification->templateLabel()); ?> · <?php echo e($lastNotification->statusLabel()); ?></p>
                            </div>
                            <?php if($lastNotification->action_url): ?>
                                <a href="<?php echo e($lastNotification->action_url); ?>" target="_blank" rel="noopener" class="shrink-0 rounded-md bg-emerald-700 px-3 py-2 text-xs font-semibold text-white">Abrir WhatsApp</a>
                            <?php endif; ?>
                        </div>
                        <textarea readonly rows="5" data-copy-message class="mt-3 w-full rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700"><?php echo e($lastNotification->message); ?></textarea>
                        <div class="mt-3 grid gap-2 sm:grid-cols-2">
                            <button type="button" data-copy-message-button class="rounded-md border border-slate-300 px-3 py-2 text-xs font-semibold">Copiar mensagem</button>
                            <form method="POST" action="<?php echo e(route('wash-orders.notifications.mark-as-sent', [$washOrder, $lastNotification])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button class="w-full rounded-md border border-emerald-300 px-3 py-2 text-xs font-semibold text-emerald-800">Marcar como enviada</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </section>

            <section class="mb-5 rounded-md border border-amber-200 bg-amber-50 p-4">
                <h2 class="font-semibold text-amber-950">Recibo</h2>
                <p class="mt-1 text-xs text-amber-800">Gere um comprovante simples da lavagem para imprimir ou salvar como PDF pelo navegador.</p>
                <a href="<?php echo e(route('wash-orders.receipt', $washOrder)); ?>" target="_blank" rel="noopener" class="mt-3 inline-flex w-full justify-center rounded-md bg-amber-700 px-4 py-2.5 text-sm font-semibold text-white">Imprimir recibo</a>
            </section>

            <h2 class="font-semibold">Atualizar status</h2>
            <form method="POST" action="<?php echo e(route('wash-orders.update-status', $washOrder)); ?>" class="mt-4 space-y-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <label class="block">
                    <span class="text-sm font-medium">Novo status</span>
                    <select name="status" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($washOrder->status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="block">
                    <span class="text-sm font-medium">Observacao</span>
                    <textarea name="notes" rows="3" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2"></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <button class="w-full rounded-md bg-cyan-700 px-4 py-2.5 text-sm font-semibold text-white">Salvar status</button>
            </form>
            <a href="<?php echo e(route('wash-orders.index')); ?>" class="mt-3 block rounded-md border border-zinc-300 px-4 py-2.5 text-center text-sm font-semibold">Voltar</a>
        </aside>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /Users/adrianofreitas/www/general-projects/lavaRapidoABS/resources/views/app/wash-orders/show.blade.php ENDPATH**/ ?>