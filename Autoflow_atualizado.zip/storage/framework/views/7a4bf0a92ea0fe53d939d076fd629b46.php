<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Historico operacional','title' => 'Historico operacional · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Historico operacional','title' => 'Historico operacional · AutoFlow']); ?>
    <div class="space-y-5">
        <section class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <form method="GET" action="<?php echo e(route('history.index')); ?>" class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Inicio</span>
                    <input name="start" type="date" value="<?php echo e($filters['start']); ?>" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Fim</span>
                    <input name="end" type="date" value="<?php echo e($filters['end']); ?>" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Cliente</span>
                    <select name="customer_id" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>" <?php if((string) $filters['customer_id'] === (string) $customer->id): echo 'selected'; endif; ?>><?php echo e($customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Placa</span>
                    <input name="plate" value="<?php echo e($filters['plate']); ?>" placeholder="ABC1D23" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm uppercase">
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Servico</span>
                    <select name="service_id" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service->id); ?>" <?php if((string) $filters['service_id'] === (string) $service->id): echo 'selected'; endif; ?>><?php echo e($service->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Status</span>
                    <select name="status" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($filters['status'] === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Funcionario</span>
                    <select name="employee_id" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($employee->id); ?>" <?php if((string) $filters['employee_id'] === (string) $employee->id): echo 'selected'; endif; ?>><?php echo e($employee->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Pagamento</span>
                    <select name="payment_method" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($filters['payment_method'] === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <div class="flex flex-wrap gap-3 md:col-span-2 xl:col-span-4">
                    <button class="rounded-md bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-800">Filtrar</button>
                    <a href="<?php echo e(route('history.index')); ?>" class="rounded-md border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Limpar</a>
                    <a href="<?php echo e(route('history.export', request()->query())); ?>" class="rounded-md border border-blue-200 bg-blue-50 px-4 py-2.5 text-sm font-semibold text-blue-700 hover:bg-blue-100">Exportar CSV</a>
                </div>
            </form>
        </section>

        <section class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                <p class="text-sm text-slate-500">Lavagens no filtro</p>
                <p class="mt-2 text-2xl font-bold"><?php echo e($summary['count']); ?></p>
            </div>
            <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                <p class="text-sm text-slate-500">Total operacional</p>
                <p class="mt-2 text-2xl font-bold">R$ <?php echo e(number_format((float) $summary['total'], 2, ',', '.')); ?></p>
            </div>
            <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                <p class="text-sm text-slate-500">Entregues</p>
                <p class="mt-2 text-2xl font-bold"><?php echo e($summary['delivered']); ?></p>
            </div>
            <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                <p class="text-sm text-slate-500">Pagas</p>
                <p class="mt-2 text-2xl font-bold"><?php echo e($summary['paid']); ?></p>
            </div>
        </section>

        <section class="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-semibold">Registros operacionais</h2>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full min-w-[1180px] text-left text-sm">
                    <thead class="bg-slate-50 text-xs uppercase text-slate-500">
                        <tr>
                            <th class="px-5 py-3">Entrada</th>
                            <th class="px-5 py-3">Ordem</th>
                            <th class="px-5 py-3">Cliente</th>
                            <th class="px-5 py-3">Veiculo</th>
                            <th class="px-5 py-3">Servicos</th>
                            <th class="px-5 py-3">Status</th>
                            <th class="px-5 py-3">Equipe</th>
                            <th class="px-5 py-3">Pagamento</th>
                            <th class="px-5 py-3 text-right">Total</th>
                            <th class="px-5 py-3 text-right">Acao</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $washOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $washOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-5 py-4 text-slate-600"><?php echo e($washOrder->entered_at?->format('d/m/Y H:i') ?? '-'); ?></td>
                                <td class="px-5 py-4 font-semibold text-slate-950"><?php echo e($washOrder->code); ?></td>
                                <td class="px-5 py-4">
                                    <p class="font-medium"><?php echo e($washOrder->customer->name); ?></p>
                                    <p class="text-xs text-slate-500"><?php echo e($washOrder->customer->phone); ?></p>
                                </td>
                                <td class="px-5 py-4">
                                    <p class="font-medium"><?php echo e($washOrder->vehicle->plate); ?></p>
                                    <p class="text-xs text-slate-500"><?php echo e($washOrder->vehicle->brand); ?> <?php echo e($washOrder->vehicle->model); ?></p>
                                </td>
                                <td class="px-5 py-4 text-slate-700">
                                    <?php echo e($washOrder->services->pluck('pivot.service_name')->filter()->join(', ') ?: '-'); ?>

                                </td>
                                <td class="px-5 py-4">
                                    <?php echo $__env->make('app.wash-orders._status-badge', ['status' => $washOrder->status, 'label' => $washOrder->statusLabel()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </td>
                                <td class="px-5 py-4 text-slate-700">
                                    <?php echo e($washOrder->teamMembers->isNotEmpty() ? $washOrder->teamMembers->pluck('name')->join(', ') : ($washOrder->assignedUser?->name ?? '-')); ?>

                                </td>
                                <td class="px-5 py-4 text-slate-700">
                                    <?php if($washOrder->payments->isNotEmpty()): ?>
                                        <?php echo e($washOrder->payments->map(fn ($payment) => $payment->methodLabel())->unique()->join(', ')); ?>

                                    <?php else: ?>
                                        <?php echo e($washOrder->paymentStatusLabel()); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="px-5 py-4 text-right font-semibold">R$ <?php echo e(number_format((float) $washOrder->total_amount, 2, ',', '.')); ?></td>
                                <td class="px-5 py-4 text-right">
                                    <a href="<?php echo e(route('wash-orders.show', $washOrder)); ?>" class="font-semibold text-blue-700 hover:text-blue-900">Abrir</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="px-5 py-10 text-center text-sm text-slate-500">Nenhuma lavagem encontrada para os filtros aplicados.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="border-t border-slate-200 px-5 py-4">
                <?php echo e($washOrders->links()); ?>

            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /Users/adrianofreitas/www/general-projects/lavaRapidoABS/resources/views/app/history/index.blade.php ENDPATH**/ ?>