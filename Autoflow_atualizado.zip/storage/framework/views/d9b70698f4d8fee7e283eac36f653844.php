<?php echo $__env->make('app.components.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="grid gap-4 md:grid-cols-2">
    <label class="block">
        <span class="text-sm font-medium">Nome</span>
        <input name="name" value="<?php echo e(old('name', $employee->name)); ?>" required class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>

    <label class="block">
        <span class="text-sm font-medium">E-mail</span>
        <input name="email" type="email" value="<?php echo e(old('email', $employee->email)); ?>" required class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>

    <label class="block">
        <span class="text-sm font-medium">Telefone</span>
        <input name="phone" value="<?php echo e(old('phone', $employee->phone)); ?>" data-mask="phone" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2" placeholder="(11) 99999-9999">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>

    <label class="block">
        <span class="text-sm font-medium">Perfil</span>
        <select name="role" required class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php if(old('role', $employee->role ?: 'operator') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>

    <label class="block">
        <span class="text-sm font-medium">Senha provisoria <?php echo e($employee->exists ? '/ reset de senha opcional' : ''); ?></span>
        <input name="password" type="password" <?php if(! $employee->exists): echo 'required'; endif; ?> class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
        <?php if($employee->exists): ?>
            <span class="mt-1 block text-xs text-zinc-500">Preencha apenas se quiser resetar a senha deste usuario.</span>
        <?php endif; ?>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>

    <?php if($employee->exists && ! $employee->is(auth()->user())): ?>
        <label class="block">
            <span class="text-sm font-medium">Status</span>
            <select name="is_active" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
                <option value="1" <?php if((string) old('is_active', (int) $employee->is_active) === '1'): echo 'selected'; endif; ?>>Ativo</option>
                <option value="0" <?php if((string) old('is_active', (int) $employee->is_active) === '0'): echo 'selected'; endif; ?>>Inativo</option>
            </select>
            <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
    <?php endif; ?>
</div>

<div class="mt-5 flex gap-2">
    <button class="rounded-md bg-cyan-700 px-4 py-2.5 text-sm font-semibold text-white">Salvar</button>
    <a href="<?php echo e(route('employees.index')); ?>" class="rounded-md border border-zinc-300 px-4 py-2.5 text-sm font-semibold">Cancelar</a>
</div>
<?php /**PATH /var/www/app/resources/views/app/employees/_form.blade.php ENDPATH**/ ?>