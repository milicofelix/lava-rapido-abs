<?php echo $__env->make('app.components.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="grid gap-4 md:grid-cols-2">
    <label class="block">
        <span class="text-sm font-medium">Nome</span>
        <input name="name" value="<?php echo e(old('name', $customer->name)); ?>" required class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>
    <label class="block">
        <span class="text-sm font-medium">Telefone / WhatsApp</span>
        <input name="phone" value="<?php echo e(old('phone', $customer->phone)); ?>" required data-mask="phone" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>
    <label class="block">
        <span class="text-sm font-medium">E-mail</span>
        <input name="email" type="email" value="<?php echo e(old('email', $customer->email)); ?>" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>
    <label class="block">
        <span class="text-sm font-medium">CPF</span>
        <input name="cpf" value="<?php echo e(old('cpf', $customer->cpf)); ?>" data-mask="cpf" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2">
        <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>
</div>

<label class="mt-4 block">
    <span class="text-sm font-medium">Observacoes</span>
    <textarea name="notes" rows="4" class="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2"><?php echo e(old('notes', $customer->notes)); ?></textarea>
    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</label>

<div class="mt-6 flex gap-3">
    <button class="rounded-md bg-cyan-700 px-4 py-2 text-sm font-semibold text-white">Salvar cliente</button>
    <a href="<?php echo e(route('customers.index')); ?>" class="rounded-md border border-zinc-300 px-4 py-2 text-sm font-semibold">Cancelar</a>
</div>
<?php /**PATH /var/www/app/resources/views/app/customers/_form.blade.php ENDPATH**/ ?>