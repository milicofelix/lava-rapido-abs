<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Bom dia, '.e(auth()->user()->name).'!','title' => 'Dashboard · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Bom dia, '.e(auth()->user()->name).'!','title' => 'Dashboard · AutoFlow']); ?>
    <div class="space-y-5">
        <?php if($currentLocation): ?>
            <section class="rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm text-blue-950 shadow-sm">
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <p class="text-xs font-black uppercase tracking-[0.18em] text-blue-700">Unidade atual</p>
                        <h2 class="mt-1 text-lg font-black"><?php echo e($currentLocation->name); ?></h2>
                        <p class="mt-1 text-blue-700">Os indicadores desta tela estao filtrados por este lava-rapido.</p>
                    </div>
                    <span class="rounded-full bg-white px-3 py-1 text-xs font-black text-blue-700"><?php echo e($currentLocation->accountStatusLabel()); ?></span>
                </div>
            </section>
        <?php endif; ?>

        <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <p class="text-xs font-black uppercase tracking-[0.18em] text-blue-700">Dashboard executivo</p>
                    <h2 class="mt-1 text-xl font-black text-slate-950">Visao do mes</h2>
                    <p class="mt-1 text-sm text-slate-500"><?php echo e(ucfirst($monthLabel)); ?></p>
                </div>
                <?php if(auth()->user()->isTeamManager()): ?>
                    <a href="<?php echo e(route('finance.index')); ?>" class="rounded-xl border border-slate-200 px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50">Abrir financeiro</a>
                <?php endif; ?>
            </div>

            <div class="mt-5 grid gap-4 lg:grid-cols-4">
                <?php $__currentLoopData = [
                    ['label' => 'Lavagens do mes', 'value' => number_format($monthlyWashOrders, 0, ',', '.'), 'hint' => 'Volume acumulado', 'color' => 'bg-blue-50 text-blue-700', 'icon' => 'M'],
                    ['label' => 'Receita do mes', 'value' => 'R$ '.number_format((float) $monthlyRevenue, 2, ',', '.'), 'hint' => 'Pagamentos recebidos', 'color' => 'bg-emerald-50 text-emerald-700', 'icon' => '$'],
                    ['label' => 'Ticket medio', 'value' => 'R$ '.number_format((float) $monthlyTicketAverage, 2, ',', '.'), 'hint' => 'Media por pagamento', 'color' => 'bg-violet-50 text-violet-700', 'icon' => 'T'],
                    ['label' => 'Clientes recorrentes', 'value' => count($monthlyRecurringCustomers), 'hint' => 'Com 2+ lavagens no mes', 'color' => 'bg-amber-50 text-amber-700', 'icon' => 'R'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                        <div class="flex items-center gap-3">
                            <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl <?php echo e($metric['color']); ?> text-sm font-black"><?php echo e($metric['icon']); ?></span>
                            <div class="min-w-0">
                                <p class="truncate text-sm font-bold text-slate-700"><?php echo e($metric['label']); ?></p>
                                <p class="mt-1 text-2xl font-black text-slate-950"><?php echo e($metric['value']); ?></p>
                                <p class="mt-1 text-xs font-semibold text-slate-500"><?php echo e($metric['hint']); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-5 grid gap-5 xl:grid-cols-2">
                <div class="rounded-xl border border-slate-200 p-4">
                    <div class="flex items-center justify-between gap-3">
                        <h3 class="font-black text-slate-950">Top servicos do mes</h3>
                        <span class="rounded-lg bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700"><?php echo e(count($monthlyTopServices)); ?> servicos</span>
                    </div>
                    <div class="mt-4 space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $monthlyTopServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="grid grid-cols-[1fr_auto] gap-3 text-sm">
                                <div class="min-w-0">
                                    <div class="flex items-center justify-between gap-3">
                                        <span class="truncate font-bold text-slate-800"><?php echo e($service['name']); ?></span>
                                        <span class="shrink-0 text-xs font-bold text-slate-500"><?php echo e($service['count']); ?> venda<?php echo e($service['count'] === 1 ? '' : 's'); ?></span>
                                    </div>
                                    <div class="mt-2 h-2 rounded-full bg-slate-100">
                                        <div class="h-2 rounded-full bg-blue-600" style="width: <?php echo e($service['percent']); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-slate-500">Nenhum servico vendido neste mes.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="rounded-xl border border-slate-200 p-4">
                    <div class="flex items-center justify-between gap-3">
                        <h3 class="font-black text-slate-950">Clientes recorrentes</h3>
                        <span class="rounded-lg bg-amber-50 px-3 py-1 text-xs font-bold text-amber-700">2+ lavagens</span>
                    </div>
                    <div class="mt-4 space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $monthlyRecurringCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="grid grid-cols-[1fr_auto] items-center gap-3 rounded-lg bg-slate-50 px-3 py-2 text-sm">
                                <div class="min-w-0">
                                    <p class="truncate font-bold text-slate-800"><?php echo e($customer['name']); ?></p>
                                    <div class="mt-2 h-2 rounded-full bg-white">
                                        <div class="h-2 rounded-full bg-amber-500" style="width: <?php echo e($customer['percent']); ?>%"></div>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <p class="font-black text-slate-950"><?php echo e($customer['count']); ?></p>
                                    <p class="text-xs text-slate-500">R$ <?php echo e(number_format((float) $customer['revenue'], 2, ',', '.')); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-slate-500">Nenhum cliente recorrente neste mes.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="grid gap-4 md:grid-cols-2 2xl:grid-cols-4">
            <?php $__currentLoopData = [
                ['label' => 'Lavagens hoje', 'value' => $washOrdersToday, 'hint' => '14% vs ontem', 'color' => 'from-blue-500 to-blue-700', 'icon' => 'L'],
                ['label' => 'Em andamento', 'value' => $activeWashOrders, 'hint' => 'Ver detalhes', 'color' => 'from-amber-400 to-orange-500', 'icon' => 'T'],
                ['label' => 'Prontas', 'value' => $readyWashOrders, 'hint' => 'Ver detalhes', 'color' => 'from-emerald-400 to-green-600', 'icon' => 'P'],
                ['label' => 'Faturamento hoje', 'value' => 'R$ '.number_format((float) $todayRevenue, 2, ',', '.'), 'hint' => '21% vs ontem', 'color' => 'from-violet-500 to-purple-700', 'icon' => '$'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div class="flex items-center justify-between gap-4">
                        <div class="flex items-center gap-4">
                            <span class="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br <?php echo e($card['color']); ?> text-xl font-bold text-white shadow-lg"><?php echo e($card['icon']); ?></span>
                            <div>
                                <p class="text-sm font-semibold text-slate-700"><?php echo e($card['label']); ?></p>
                                <p class="mt-2 text-2xl font-bold text-slate-950"><?php echo e($card['value']); ?></p>
                                <p class="mt-2 text-xs font-semibold text-green-600"><?php echo e($card['hint']); ?></p>
                            </div>
                        </div>
                        <div class="hidden h-12 w-20 items-end gap-1 sm:flex">
                            <?php $__currentLoopData = [20, 34, 26, 48, 42, 60]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="w-2 rounded-full bg-gradient-to-t <?php echo e($card['color']); ?>" style="height: <?php echo e($bar); ?>%"></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <section class="grid gap-5 2xl:grid-cols-[1fr_420px]">
            <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
                    <div class="flex items-center gap-3">
                        <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-sm font-bold text-blue-700">K</span>
                        <h2 class="text-xl font-bold">Fluxo de Lavagens</h2>
                    </div>
                    <div class="flex gap-2">
                        <a href="<?php echo e(route('kanban')); ?>" class="rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold">Visualizacao: Kanban</a>
                        <a href="<?php echo e(route('wash-orders.index')); ?>" class="rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold">Filtrar</a>
                    </div>
                </div>

                <div class="grid gap-3 xl:grid-cols-4">
                    <?php $__currentLoopData = $kanbanColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $columnColor = match ($column['key']) {
                                'washing' => 'border-t-blue-600 text-blue-700 bg-blue-50',
                                'finishing' => 'border-t-orange-500 text-orange-600 bg-orange-50',
                                'ready' => 'border-t-green-600 text-green-700 bg-green-50',
                                default => 'border-t-slate-400 text-slate-700 bg-slate-50',
                            };
                        ?>
                        <div class="min-h-[430px] rounded-xl border border-slate-200 border-t-4 <?php echo e($columnColor); ?> p-2">
                            <div class="flex items-center justify-between px-2 py-2">
                                <h3 class="font-bold"><?php echo e($column['title']); ?></h3>
                                <span class="rounded-full bg-white px-2 py-1 text-xs font-bold text-slate-700 shadow-sm"><?php echo e($column['count']); ?></span>
                            </div>

                            <div class="space-y-2">
                                <?php $__empty_1 = true; $__currentLoopData = $column['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a href="<?php echo e(route('wash-orders.show', $order['id'])); ?>" class="block rounded-lg border border-slate-200 bg-white p-3 text-slate-950 shadow-sm hover:border-blue-200">
                                        <div class="flex items-start justify-between gap-3">
                                            <div>
                                                <p class="font-bold"><?php echo e($order['plate']); ?></p>
                                                <p class="mt-1 text-xs text-slate-600"><?php echo e($order['customer']); ?></p>
                                            </div>
                                            <span class="text-xs font-bold text-slate-500"><?php echo e($order['brand']); ?></span>
                                        </div>
                                        <p class="mt-3 text-xs font-semibold"><?php echo e($order['service']); ?></p>
                                        <p class="mt-3 text-xs text-slate-500">Inicio: <?php echo e($order['time']); ?></p>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="rounded-lg border border-dashed border-slate-200 bg-white/50 px-3 py-8 text-center text-sm text-slate-500">Sem lavagens.</div>
                                <?php endif; ?>
                            </div>

                            <?php if($column['remaining'] > 0): ?>
                                <p class="mt-3 text-center text-sm font-semibold">+ <?php echo e($column['remaining']); ?> na fila</p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <aside class="space-y-4">
                <section class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <h2 class="font-bold">Atividades recentes</h2>
                    <div class="mt-4 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex gap-3">
                                <span class="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg <?php echo e($activity['color']); ?> text-xs font-bold text-white">A</span>
                                <div class="min-w-0 flex-1">
                                    <div class="flex justify-between gap-3">
                                        <p class="truncate text-sm font-bold"><?php echo e($activity['title']); ?></p>
                                        <span class="shrink-0 text-xs text-slate-500">Ha <?php echo e($activity['time']); ?></span>
                                    </div>
                                    <p class="text-xs text-slate-500"><?php echo e($activity['subtitle']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-slate-500">Nenhuma atividade recente.</p>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo e(route('wash-orders.index')); ?>" class="mt-5 block text-center text-sm font-bold text-blue-700">Ver todas as atividades -></a>
                </section>
            </aside>
        </section>

        <section class="grid gap-5 xl:grid-cols-2">
            <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <h2 class="font-bold">Resumo Financeiro</h2>
                    <?php if(auth()->user()->isTeamManager()): ?>
                        <a href="<?php echo e(route('finance.index')); ?>" class="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold">Hoje</a>
                    <?php endif; ?>
                </div>
                <p class="mt-5 text-2xl font-bold">R$ <?php echo e(number_format((float) $todayRevenue, 2, ',', '.')); ?></p>
                <p class="text-sm text-slate-500">Faturamento liquido</p>

                <div class="mt-5 grid gap-5 md:grid-cols-[180px_1fr]">
                    <div class="relative mx-auto h-36 w-36 rounded-full bg-[conic-gradient(#2563eb_0_35%,#10b981_35%_76%,#f59e0b_76%_95%,#8b5cf6_95%_100%)]">
                        <div class="absolute inset-8 rounded-full bg-white"></div>
                    </div>
                    <div class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $financeByMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="grid grid-cols-[1fr_auto_auto] items-center gap-3 text-sm">
                                <span class="flex items-center gap-2"><span class="h-2.5 w-2.5 rounded-full <?php echo e($method['color']); ?>"></span><?php echo e($method['label']); ?></span>
                                <strong>R$ <?php echo e(number_format((float) $method['total'], 2, ',', '.')); ?></strong>
                                <span class="text-slate-500"><?php echo e(number_format($method['percent'], 0)); ?>%</span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-slate-500">Nenhum pagamento hoje.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if(auth()->user()->isTeamManager()): ?>
                    <a href="<?php echo e(route('finance.index')); ?>" class="mt-5 block border-t border-slate-200 pt-4 text-center text-sm font-bold text-blue-700">Ver relatorio completo</a>
                <?php endif; ?>
            </div>

            <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <h2 class="font-bold">Servicos mais realizados</h2>
                    <span class="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold">Hoje</span>
                </div>
                <div class="mt-6 space-y-4">
                    <?php $__empty_1 = true; $__currentLoopData = $topServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="grid grid-cols-[160px_1fr_40px_42px] items-center gap-3 text-sm">
                            <span class="truncate font-semibold"><?php echo e($service['name']); ?></span>
                            <div class="h-2 rounded-full bg-slate-100">
                                <div class="h-2 rounded-full bg-blue-600" style="width: <?php echo e($service['percent']); ?>%"></div>
                            </div>
                            <span class="text-right font-semibold"><?php echo e($service['count']); ?></span>
                            <span class="text-right text-slate-500"><?php echo e(number_format($service['percent'], 0)); ?>%</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-slate-500">Nenhum servico vendido nesta semana.</p>
                    <?php endif; ?>
                </div>
                <?php if(auth()->user()->isTeamManager()): ?>
                    <a href="<?php echo e(route('services.index')); ?>" class="mt-5 block border-t border-slate-200 pt-4 text-center text-sm font-bold text-blue-700">Ver todos os servicos</a>
                <?php endif; ?>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/dashboard.blade.php ENDPATH**/ ?>