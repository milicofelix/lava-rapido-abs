<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Auditoria','title' => 'Auditoria · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Auditoria','title' => 'Auditoria · AutoFlow']); ?>
    <div class="space-y-5">
        <section class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <form method="GET" action="<?php echo e(route('audit-logs.index')); ?>" class="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Inicio</span>
                    <input name="start" type="date" value="<?php echo e($filters['start']); ?>" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Fim</span>
                    <input name="end" type="date" value="<?php echo e($filters['end']); ?>" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Acao</span>
                    <select name="action" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                        <option value="">Todas</option>
                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($filters['action'] === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Usuario</span>
                    <select name="user_id" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php if((string) $filters['user_id'] === (string) $user->id): echo 'selected'; endif; ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="block">
                    <span class="text-sm font-semibold text-slate-700">Busca</span>
                    <input name="search" value="<?php echo e($filters['search']); ?>" placeholder="Cliente, lavagem, detalhe" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                </label>

                <div class="flex flex-wrap gap-3 md:col-span-2 xl:col-span-5">
                    <button class="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-800">Filtrar</button>
                    <a href="<?php echo e(route('audit-logs.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Limpar</a>
                </div>
            </form>
        </section>

        <section class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-semibold">Registro de acoes</h2>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full min-w-[980px] text-left text-sm">
                    <thead class="bg-slate-50 text-xs uppercase text-slate-500">
                        <tr>
                            <th class="px-5 py-3">Quando</th>
                            <th class="px-5 py-3">Usuario</th>
                            <th class="px-5 py-3">Acao</th>
                            <th class="px-5 py-3">Registro</th>
                            <th class="px-5 py-3">Descricao</th>
                            <th class="px-5 py-3">Origem</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-5 py-4 text-slate-600"><?php echo e($log->created_at->format('d/m/Y H:i')); ?></td>
                                <td class="px-5 py-4">
                                    <p class="font-semibold text-slate-950"><?php echo e($log->user?->name ?? 'Sistema'); ?></p>
                                    <p class="text-xs text-slate-500"><?php echo e($log->user?->roleLabel() ?? '-'); ?></p>
                                </td>
                                <td class="px-5 py-4">
                                    <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700"><?php echo e($log->actionLabel()); ?></span>
                                </td>
                                <td class="px-5 py-4 font-semibold text-slate-800"><?php echo e($log->subject_label ?? '-'); ?></td>
                                <td class="px-5 py-4 text-slate-700"><?php echo e($log->description); ?></td>
                                <td class="px-5 py-4 text-xs text-slate-500"><?php echo e($log->ip_address ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="px-5 py-10 text-center text-sm text-slate-500">Nenhum registro de auditoria encontrado.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="border-t border-slate-200 px-5 py-4">
                <?php echo e($logs->links()); ?>

            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/audit-logs/index.blade.php ENDPATH**/ ?>