<?php if (isset($component)) { $__componentOriginala3210124a900b8801aa308c01d278fb8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3210124a900b8801aa308c01d278fb8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.layout','data' => ['heading' => 'Fiado / Contas a receber','title' => 'Fiado · AutoFlow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Fiado / Contas a receber','title' => 'Fiado · AutoFlow']); ?>
    <div class="space-y-5">
        ('app.components.errors')

        <div class="flex flex-wrap items-center justify-between gap-3">
            <p class="text-sm text-slate-500">Lavagens marcadas como fiado / pendente e recebimento posterior.</p>
            <div class="flex gap-2">
                <a href="<?php echo e(route('finance.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold">Financeiro</a>
                <?php if(\App\Models\AppSetting::isModuleEnabled('module_cash_register')): ?>
                    <a href="<?php echo e(route('finance.cash-registers.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold">Caixa</a>
                <?php endif; ?>
            </div>
        </div>

        <section class="grid gap-4 md:grid-cols-3">
            <div class="rounded-xl border border-slate-200 bg-white p-5">
                <p class="text-sm text-slate-500">Total pendente</p>
                <p class="mt-2 text-2xl font-semibold">R$ <?php echo e(number_format((float) $totalPending, 2, ',', '.')); ?></p>
            </div>
            <div class="rounded-xl border border-slate-200 bg-white p-5">
                <p class="text-sm text-slate-500">Ordens pendentes</p>
                <p class="mt-2 text-2xl font-semibold"><?php echo e($orders->total()); ?></p>
            </div>
            <div class="rounded-xl border border-amber-200 bg-amber-50 p-5">
                <p class="text-sm text-amber-700">Proximo passo</p>
                <p class="mt-2 font-semibold text-amber-950">Receber e baixar no financeiro</p>
            </div>
        </section>

        <section class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-semibold">Contas em aberto</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="grid gap-4 px-5 py-5 xl:grid-cols-[1fr_420px]">
                        <div>
                            <div class="flex flex-wrap items-center gap-2">
                                <a href="<?php echo e(route('wash-orders.show', $order)); ?>" class="text-lg font-semibold text-blue-700 hover:text-blue-900"><?php echo e($order->code); ?></a>
                                <span class="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800"><?php echo e($order->paymentStatusLabel()); ?></span>
                            </div>
                            <p class="mt-2 text-sm text-slate-600"><?php echo e($order->customer->name); ?> · <?php echo e($order->vehicle->plate); ?> · <?php echo e($order->vehicle->brand); ?> <?php echo e($order->vehicle->model); ?></p>
                            <p class="mt-1 text-sm text-slate-500">Entrada: <?php echo e($order->entered_at?->format('d/m/Y H:i')); ?></p>
                            <p class="mt-3 text-2xl font-semibold">R$ <?php echo e(number_format((float) $order->total_amount, 2, ',', '.')); ?></p>
                        </div>

                        <form method="POST" action="<?php echo e(route('finance.credit-receivables.receive', $order)); ?>" class="rounded-lg border border-slate-200 bg-slate-50 p-4">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="grid gap-3 md:grid-cols-2">
                                <label class="block">
                                    <span class="text-sm font-medium">Metodo</span>
                                    <select name="method" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2">
                                        <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label class="block">
                                    <span class="text-sm font-medium">Valor recebido</span>
                                    <input name="amount" type="number" step="0.01" min="0.01" value="<?php echo e(old('amount', $order->total_amount)); ?>" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2">
                                </label>
                            </div>
                            <label class="mt-3 block">
                                <span class="text-sm font-medium">Observacao</span>
                                <input name="notes" value="<?php echo e(old('notes')); ?>" class="mt-1 w-full rounded-md border border-slate-300 px-3 py-2" placeholder="Ex: Recebido via Pix depois da retirada">
                            </label>
                            <button class="mt-4 rounded-md bg-emerald-700 px-4 py-2.5 text-sm font-semibold text-white">Marcar como recebido</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-10 text-center text-slate-500">Nenhum fiado em aberto.</p>
                <?php endif; ?>
            </div>
            <div class="border-t border-slate-200 px-5 py-4">
                <?php echo e($orders->links()); ?>

            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $attributes = $__attributesOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__attributesOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3210124a900b8801aa308c01d278fb8)): ?>
<?php $component = $__componentOriginala3210124a900b8801aa308c01d278fb8; ?>
<?php unset($__componentOriginala3210124a900b8801aa308c01d278fb8); ?>
<?php endif; ?>
<?php /**PATH /var/www/app/resources/views/app/finance/credit-receivables/index.blade.php ENDPATH**/ ?>